![banner](https://socialify.git.ci/PhiTea/mclang-hg_HG/image?description=1&font=Bitter&forks=1&issues=1&language=1&logo=https%3A%2F%2Favatars2.githubusercontent.com%2Fu%2F73832708%3Fs%3D400%26u%3Db50b92d40e7f4c474f6674f9eebeb4909dce4d2b%26v%3D4&owner=1&pattern=Overlapping%20Hexagons&pulls=1&stargazers=1&theme=Light)

# mclang-hg_HG

:rofl:我的世界火锅简体中文(hg_HG)语言包。
